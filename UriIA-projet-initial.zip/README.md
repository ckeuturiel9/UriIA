# UriIA — prototype mobile

UriIA est un site web mobile qui prépare :
- des scripts et storyboards de vidéos ;
- des prompts à copier dans un générateur d'images ;
- des publications et hashtags.

## Ce que cette première version fait / ne fait pas

- Sans clé API : mode démo local avec des modèles de texte. Ce n'est pas une IA générative.
- Avec une clé Gemini valide : génération de texte via l'API Gemini, selon le modèle, le quota et les conditions de ton compte.
- La version initiale ne génère pas directement un fichier vidéo ou image. Elle produit des scripts, storyboards et prompts. L'image/vidéo réelle nécessite ensuite une API ou un outil de génération séparé, qui peut être payant.

## Lancer dans un environnement Node.js (20 ou plus)

1. Copier `.env.example` vers `.env`.
2. (Facultatif) Ajouter la clé dans `GEMINI_API_KEY` dans `.env`.
3. Installer et lancer :

```bash
npm install
npm start
```

4. Ouvrir `http://localhost:3000`.

## Depuis un téléphone via GitHub Codespaces

1. Dans le navigateur du téléphone, connecte-toi à https://github.com.
2. Crée un dépôt privé nommé `uria`.
3. Ajoute les fichiers de ce projet au dépôt (tu peux d'abord décompresser le ZIP sur un ordinateur, ou téléverser les fichiers si ton interface mobile le permet).
4. Dans le dépôt GitHub, appuie sur **Code → Codespaces → Create codespace on main**.
5. Dans le terminal du Codespace, exécute :

```bash
npm install
cp .env.example .env
npm start
```

6. Dans le panneau **Ports**, ouvre le port `3000` dans le navigateur. Le Codespace doit rester actif pour que l'application fonctionne. GitHub fournit un quota mensuel limité et peut bloquer l'utilisation quand ce quota est épuisé.

## Activer l'IA texte (facultatif)

1. Ouvre https://aistudio.google.com/ et crée une clé API si ton compte et ta région le permettent.
2. Dans le Codespace, crée un fichier `.env` (il est ignoré par Git) et mets :

```dotenv
GEMINI_API_KEY=COLLE_TA_CLE_ICI
GEMINI_MODEL=gemini-2.5-flash
PORT=3000
```

3. Redémarre le serveur avec `npm start`. Ne colle jamais la clé dans `public/index.html`, dans un message public, ni dans GitHub.
4. Vérifie le quota et les conditions de facturation dans AI Studio. Le code ne configure pas de paiement automatiquement.

## Sécurité et limites

- `.env` est exclu de Git grâce à `.gitignore`.
- La clé n'est utilisée que par `server.js`, côté serveur.
- Limitation simple à 10 requêtes par minute par adresse IP ; ce n'est pas une protection suffisante pour une application publique à grande échelle.
- Pas encore de compte utilisateur, de base de données, d'historique, de stockage des médias ni de publication automatique.
- N'ajoute pas de clé API à un dépôt public.
- Les offres gratuites, modèles disponibles et quotas peuvent changer. Vérifie les conditions actuelles avant usage.

## Déploiement public

Pour un site accessible en permanence, déploie le serveur sur un hébergeur Node.js qui prend en charge les variables d'environnement. Définis `GEMINI_API_KEY` dans les paramètres de secrets de l'hébergeur, jamais dans le code. Vérifie les limites du plan gratuit, la veille/suspension et les conditions de paiement avant de choisir.
