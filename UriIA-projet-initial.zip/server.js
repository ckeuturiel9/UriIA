import express from "express";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);

app.disable("x-powered-by");
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public"), {
  extensions: ["html"],
  maxAge: process.env.NODE_ENV === "production" ? "1h" : 0
}));

const generationLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Trop de demandes. Attends une minute puis réessaie." }
});
app.use("/api/generate", generationLimiter);

const MODES = new Set(["video", "image", "post"]);
const clean = (s, max = 1200) => String(s ?? "").trim().slice(0, max);

function makePrompt(mode, topic, platform, tone, language) {
  const common = `Réponds en ${language}. Sujet : ${topic}. Ton : ${tone}. Plateforme cible : ${platform}. N'invente pas de faits précis. Le résultat doit être exploitable et original.`;
  if (mode === "video") return `${common}
Tu es UriIA, assistant de création vidéo courte. Prépare :
1. un titre accrocheur ;
2. un concept en une phrase ;
3. un script de narration de 30 à 45 secondes ;
4. un storyboard de 5 scènes avec pour chaque scène : durée, visuel, action/cadrage, voix off/dialogue ;
5. un prompt d'image/vidéo en français ou anglais pour chaque scène ;
6. une légende, 5 hashtags et un appel à l'action.
Important : tu prépares le script et le storyboard, tu ne prétends pas avoir rendu un fichier vidéo.`;
  if (mode === "image") return `${common}
Tu es UriIA, directeur artistique. Produis :
1. une idée visuelle ;
2. un prompt détaillé prêt à copier dans un générateur d'images (sujet, composition, lumière, couleurs, décor, style, cadrage vertical 9:16 si pertinent) ;
3. un prompt négatif si utile ;
4. trois variantes créatives ;
5. une légende courte et 5 hashtags.
Important : tu écris des prompts, tu ne prétends pas avoir généré un fichier image.`;
  return `${common}
Tu es UriIA, spécialiste des réseaux sociaux. Prépare :
1. trois accroches différentes ;
2. une publication prête à copier, avec emojis modérés ;
3. une version courte ;
4. un appel à l'action ;
5. 8 hashtags pertinents ;
6. une suggestion de visuel et son prompt d'image.
N'invente pas de résultats, de témoignages ou de chiffres.`;
}

function demoResult(mode, topic, platform, tone, language) {
  const title = topic.charAt(0).toUpperCase() + topic.slice(1);
  if (mode === "video") return `URI IA — MODE DÉMO\n\nTITRE\n${title}\n\nCONCEPT\nUne courte histoire claire et engageante sur : ${topic}.\n\nSCRIPT (30–45 s)\n« Aujourd'hui, découvrons ${topic}. Reste jusqu'à la fin pour retenir l'essentiel. Premièrement, présente le contexte. Ensuite, montre un exemple concret. Enfin, termine par une idée simple que chacun peut appliquer. Qu'en penses-tu ? »\n\nSTORYBOARD\n1. 0–5 s — Plan d'ouverture avec un titre à l'écran. Voix off : introduire le sujet.\n2. 5–12 s — Montrer le contexte et le problème.\n3. 12–22 s — Illustrer le point principal avec une scène concrète.\n4. 22–35 s — Donner une solution ou un élément surprenant.\n5. 35–45 s — Conclusion, question au public et appel à l'action.\n\nPROMPT VISUEL\nVidéo verticale 9:16, sujet « ${topic} », composition cinématographique, lumière naturelle, mouvements de caméra fluides, détails réalistes, sous-titres lisibles, rendu propre pour ${platform}.\n\nLÉGENDE\n${title} : découvre l'idée et dis-moi ce que tu en penses !\n\n#CréationDeContenu #Vidéo #Inspiration #UriIA #${platform.replace(/[^a-z0-9]/gi, "")}\n\nNote : mode démo, ce résultat est un modèle de départ, pas une réponse générée par un modèle IA.`;
  if (mode === "image") return `URI IA — MODE DÉMO\n\nIDÉE VISUELLE\nUne image qui illustre clairement : ${topic}.\n\nPROMPT À COPIER\nImage verticale 4:5, sujet principal : ${topic}, composition professionnelle, détails nets, lumière naturelle douce, couleurs harmonieuses, arrière-plan cohérent, cadrage soigné, profondeur de champ subtile, qualité éditoriale, sans texte ni filigrane.\n\nVARIANTES\n1. Style photo réaliste et cinématographique.\n2. Illustration numérique moderne et colorée.\n3. Affiche minimaliste avec espace libre pour ajouter un titre ensuite.\n\nPROMPT NÉGATIF\nflou, texte illisible, filigrane, mains déformées, éléments dupliqués, faible résolution.\n\nLÉGENDE\nUne nouvelle façon de voir ${topic}.\n\n#Art #Image #Créativité #Design #UriIA\n\nNote : mode démo, UriIA fournit un prompt, pas un fichier image généré.`;
  return `URI IA — MODE DÉMO\n\nACCROCHES\n1. Et si on regardait ${topic} autrement ?\n2. Voici ce qu'il faut retenir sur ${topic}.\n3. Prêt à découvrir quelque chose de nouveau ?\n\nPUBLICATION\n✨ Parlons de ${topic} !\nVoici une idée simple à découvrir, partager et discuter. Quel est ton avis ? Écris-le en commentaire et partage cette publication avec quelqu'un que cela peut intéresser.\n\nVERSION COURTE\n${title} : qu'en penses-tu ? Dis-le en commentaire 👇\n\nAPPEL À L'ACTION\nCommente, partage et abonne-toi pour plus de contenu.\n\nHASHTAGS\n#${platform.replace(/[^a-z0-9]/gi, "")} #CréationDeContenu #Inspiration #Découverte #Communauté #UriIA #Tendance #ÀPartager\n\nIDÉE DE VISUEL\nUn visuel propre centré sur « ${topic} », avec un contraste net et une composition lisible sur téléphone.\n\nNote : mode démo, ce résultat est un modèle de départ, pas une réponse générée par un modèle IA.`;
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, mode: process.env.GEMINI_API_KEY ? "gemini" : "demo" });
});

app.post("/api/generate", async (req, res) => {
  const mode = clean(req.body?.mode, 20);
  const topic = clean(req.body?.topic, 1200);
  const platform = clean(req.body?.platform || "TikTok", 40);
  const tone = clean(req.body?.tone || "créatif et naturel", 60);
  const language = clean(req.body?.language || "français", 30);

  if (!MODES.has(mode)) return res.status(400).json({ error: "Choisis vidéo, image ou publication." });
  if (topic.length < 3) return res.status(400).json({ error: "Écris un sujet d'au moins 3 caractères." });

  // Mode démo : aucun appel externe, aucune clé nécessaire.
  if (!process.env.GEMINI_API_KEY) {
    return res.json({ result: demoResult(mode, topic, platform, tone, language), mode: "demo" });
  }

  try {
    const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": process.env.GEMINI_API_KEY
      },
      body: JSON.stringify({
        contents: [{ parts: [{ text: makePrompt(mode, topic, platform, tone, language) }] }],
        generationConfig: { temperature: 0.8, maxOutputTokens: 2200 }
      }),
      signal: AbortSignal.timeout(45000)
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      console.error("Gemini API error status:", response.status);
      return res.status(502).json({
        error: response.status === 429
          ? "Limite d'utilisation atteinte. Réessaie plus tard ou vérifie le quota du modèle."
          : "Le service IA a refusé la demande. Vérifie le modèle, la clé et les limites dans AI Studio."
      });
    }
    const result = (data.candidates?.[0]?.content?.parts || [])
      .map(part => part.text || "")
      .join("\n")
      .trim();
    if (!result) return res.status(502).json({ error: "L'IA n'a pas renvoyé de texte. Réessaie." });
    return res.json({ result, mode: "gemini" });
  } catch (error) {
    console.error("Generation error:", error.name || "Error");
    return res.status(504).json({ error: "Délai dépassé ou service indisponible. Réessaie." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`UriIA démarré sur le port ${PORT}`);
});
